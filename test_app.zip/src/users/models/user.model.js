module.exports = function(sequelize, DataTypes) {
    const User = sequelize.define("user", {
        email:{
            field:'Email', 
            type:DataTypes.STRING(255),
            unique:true 
        },
        phone_number:{
            field:'Phone Number', 
            unique:true,
            type:DataTypes.STRING(255)
        },
        is_subscribed:{
            field:'Is Subscribed', 
            default:false, 
            type:DataTypes.BOOLEAN
        },
        is_verified:{
            field:'Is Verified', 
            default:false, 
            type:DataTypes.BOOLEAN
        },
        notification_disabled:{
            field:'Notifications Disabled', 
            default:false, 
            type:DataTypes.BOOLEAN
        },
        password:{
            field:'Password', 
            unique:true,
            type:DataTypes.CHAR(255)
        },
        first_name:{
            field:'First Name', 
            unique:true,
            type:DataTypes.STRING
        },
        last_name:{
            field:'Last Name', 
            unique:true,
            type:DataTypes.STRING
        }
        // subscription_id = models.CharField(_("Subscription ID"), max_length=50, null=True, blank=True)
        // subscription_date = models.DateField("Subscription Date", blank=True, null=True)
        // qr_serial = models.CharField("QR Serial", max_length=4, db_index=True, blank=True)
        
    });

    return User;
}