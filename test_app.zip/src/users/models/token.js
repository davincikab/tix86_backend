module.exports = (sequelize, DataTypes) => {
    const Token = sequelize.define( "token", {
        id: {
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            type: DataTypes.INTEGER
        },
        userId: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        expires_on:{
            type:DataTypes.DATE,
            allowNull:false
        },        
        token: {
            type: DataTypes.STRING,
            unique:true,
            allowNull:false
        },
    }, {timestamps: true}, )

    return Token;
}