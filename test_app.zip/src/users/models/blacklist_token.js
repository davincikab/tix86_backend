module.exports = (sequelize, DataTypes) => {
    const BlackListToken = sequelize.define( "blacklist_token", {
        id: {
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            type: DataTypes.INTEGER
        },
        token: {
            type: DataTypes.STRING(500),
            unique:true,
            allowNull:false
        },
    }, {timestamps: true}, )

    return BlackListToken;
}