module.exports = (sequelize, DataTypes) => {
    const Otp = sequelize.define( "otp_model", {
        id: {
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            type: DataTypes.INTEGER
        },
        email: {
            type: DataTypes.STRING,
            allowNull: false
        },

        userId: {
            type: DataTypes.INTEGER,
            allowNull: false
        },

        otp: {
            type: DataTypes.STRING,
            unique:true,
            allowNull:false
        },
    }, {timestamps: true}, )

    // Otp.addHook('afterCreate', (otp, options) => {
    //     sendVerificationEmail(otp.userId, otp.otp);
    // });

    return Otp;
};