const { DataTypes } = require('sequelize');
const db = require("../../../services/db");

const User = require("./user.model.js")(db.sequelize, DataTypes);
const Role = require("./roles.model.js")(db.sequelize, DataTypes);
const Token = require("./token.js")(db.sequelize, DataTypes);
const OTP = require("./otp.models.js")(db.sequelize, DataTypes);
const BlackListToken = require("./blacklist_token.js")(db.sequelize, DataTypes);

// User - token relationship
User.hasOne(Token, { foreignKey: 'userId', as:'token' });
Token.belongsTo(User, { foreignKey: 'userId' });

// user - roles relationship
Role.belongsToMany(User, {
    through: "user_roles",
});

User.belongsToMany(Role, {
    through: "user_roles"
});

// otp user relation
// User.hasOne(OTP, { foreignKey: 'userId', as:'otp' });
// OTP.belongsTo(User, { foreignKey: 'userId' });


// db.sequelize.sync({ force:false });
// User.sync({ force:true });
// OTP.sync({ force:true });
// Role.sync({ force:true });

// BlackListToken.sync({ force:true });
function initialize() {
    Role.create({
     id: 1,
     name: "customer"
   });
  
   Role.create({
     id: 2,
     name: "moderator"
   });
  
   Role.create({
     id: 3,
     name: "admin"
   });
}

// Token.sync({ force:true });

// initialize();
module.exports = { User, Token, Role, OTP, BlackListToken };