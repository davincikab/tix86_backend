const authRouter = require("./routes/auth.routes");
const otpRouter = require("./routes/otp.routes");
const userRouter = require("./routes/user.routes");


module.exports = { authRouter, otpRouter, userRouter};